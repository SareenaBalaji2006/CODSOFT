import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score
import warnings
warnings.filterwarnings('ignore')
df = pd.read_csv('creditcard.csv')
print("✅ Data loaded:", df.shape)  
print("Class distribution:")
print(df['Class'].value_counts(normalize=True)) 
X = df.drop('Class', axis=1)
y = df['Class']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
print("\nTraining Logistic Regression...")
lr = LogisticRegression(class_weight='balanced', max_iter=1000, random_state=42)
lr.fit(X_train, y_train)
lr_pred = lr.predict(X_test)
print("\nLogistic Regression Results:")
print(classification_report(y_test, lr_pred, target_names=['Genuine', 'FRAUD']))
print("F1-score:", f1_score(y_test, lr_pred))
print("Confusion Matrix:\n", confusion_matrix(y_test, lr_pred))
print("\nTraining Random Forest...")
rf = RandomForestClassifier(n_estimators=100, class_weight='balanced', random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)
rf_pred = rf.predict(X_test)
print("\nRandom Forest Results:")
print(classification_report(y_test, rf_pred, target_names=['Genuine', 'FRAUD']))
print("FRAUD CLASS PERFORMANCE:")
print(f"Precision: {classification_report(y_test, rf_pred, output_dict=True)['1']['precision']:.3f}")
print(f"Recall:    {classification_report(y_test, rf_pred, output_dict=True)['1']['recall']:.3f}")
print(f"F1-Score:  {f1_score(y_test, rf_pred):.3f}")
print("Confusion Matrix (Genuine | FRAUD):")
print(confusion_matrix(y_test, rf_pred))
import matplotlib.pyplot as plt
import seaborn as sns
plt.figure(figsize=(10,6))
plt.barh(X.columns[:10], rf.feature_importances_[:10])
plt.title("🔍 TOP 10 FRAUD DETECTION FEATURES")
plt.show()
cm = confusion_matrix(y_test, rf_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',  xticklabels=['Genuine', 'FRAUD'], yticklabels=['Genuine', 'FRAUD'])
plt.title('🚨 FRAUD DETECTION - CONFUSION MATRIX')
plt.show()
