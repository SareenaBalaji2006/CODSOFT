import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# 1. Load dataset
train = pd.read_csv("")

# 2. Select simple features
features = ["Pclass", "Sex", "Age", "SibSp", "Parch", "Fare", "Embarked"]

# 3. Convert categorical to numbers
train = train.dropna(subset=["Age", "Embarked"])  # drop missing rows for simplicity
X = pd.get_dummies(train[features])
y = train["Survived"]

# 4. Split data
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# 5. Train model
model = LogisticRegression(max_iter=200)
model.fit(X_train, y_train)

# 6. Evaluate
preds = model.predict(X_val)
print("Accuracy:", accuracy_score(y_val, preds))
