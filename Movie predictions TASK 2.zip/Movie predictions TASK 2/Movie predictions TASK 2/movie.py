import os
import pandas as pd

# Go to Documents folder correctly
os.chdir(r'C:\Users\saree\OneDrive\Sareena Study')

print("✅ Now in Documents folder!")
print("Files here:", os.listdir('.'))

# Load CSV file
df = pd.read_csv('IMDB Movies India.csv',encoding='latin1')

print("\n✅ MOVIE DATA LOADED!")
print("Shape:", df.shape)
print("Columns:", df.columns.tolist())
print("\nFirst 3 rows:")
print(df.head(3))


# Clean Rating column (remove non-numeric)
df['Rating'] = pd.to_numeric(df['Rating'], errors='coerce')

# Drop rows with missing ratings
df = df.dropna(subset=['Rating'])

# Fill missing Genre/Director safely
df['Genre'] = df['Genre'].fillna('Unknown')
df['Director'] = df['Director'].fillna('Unknown')

print("✅ Data cleaned!")
print("Final shape:", df.shape)
from sklearn.preprocessing import LabelEncoder

# Encode Genre and Director
le_genre = LabelEncoder()
le_director = LabelEncoder()

df['Genre_encoded'] = le_genre.fit_transform(df['Genre'])
df['Director_encoded'] = le_director.fit_transform(df['Director'])

# Convert Year to numeric
df['Year'] = pd.to_numeric(df['Year'], errors='coerce')

print("✅ Features ready!")
print(df[['Genre', 'Genre_encoded', 'Director', 'Director_encoded', 'Rating']].head())
# Features for prediction
features = ['Genre_encoded', 'Director_encoded', 'Year']
X = df[features].fillna(0)
y = df['Rating']

print("Features shape:", X.shape)
print("Ratings shape:", y.shape)
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train Random Forest model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Predict & evaluate
y_pred = model.predict(X_test)
r2 = r2_score(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

print(f"✅ Model trained!")
print(f"R² Score: {r2:.4f}")
print(f"RMSE: {rmse:.4f}")
import matplotlib.pyplot as plt
import seaborn as sns

# Feature importance
importance = pd.DataFrame({
    'Feature': features,
    'Importance': model.feature_importances_
}).sort_values('Importance', ascending=True)

print("Feature Importance:")
print(importance)

# Plot
plt.figure(figsize=(8, 5))
sns.barplot(data=importance, x='Importance', y='Feature')
plt.title('Movie Rating Prediction - Feature Importance')
plt.show()

def safe_transform(le, labels):
    """Transform labels safely, mapping unseen ones to -1."""
    return [le.transform([l])[0] if l in le.classes_ else -1 for l in labels]

# Predict rating for new movie
new_movie = pd.DataFrame({
    'Genre_encoded': [le_genre.transform(['Drama'])[0]],
    'Director_encoded': safe_transform(le_director, ['S.S. Rajamouli'])[0],
    'Year': [2024]
})

predicted_rating = model.predict(new_movie)
print(f"Predicted Rating: {predicted_rating[0]:.2f}/10")
# 🔥 ACTION MOVIE PREDICTIONS 🔥
print("=== ACTION MOVIE RATINGS ===")

def safe_transform(le, labels):
    return [le.transform([l])[0] if l in le.classes_ else -1 for l in labels]

# Action + Top Directors
print("=== ACTION MOVIE RATINGS ===")

new_movie = pd.DataFrame({
    'Genre_encoded': [le_genre.transform(['Action'])[0]],
    'Director_encoded': safe_transform(le_director, ['S.S. Rajamouli'])[0],
    'Year': [2026]
})
print(f"🚀 Action + Rajamouli: {model.predict(new_movie)[0]:.2f}/10")

new_movie = pd.DataFrame({
    'Genre_encoded': [le_genre.transform(['Action'])[0]],
    'Director_encoded': safe_transform(le_director, ['Rohit Shetty'])[0],
    'Year': [2026]
})
print(f"💥 Action + Rohit Shetty: {model.predict(new_movie)[0]:.2f}/10")

new_movie = pd.DataFrame({
    'Genre_encoded': [le_genre.transform(['Action'])[0]],
    'Director_encoded': safe_transform(le_director, ['Anurag Kashyap'])[0],
    'Year': [2026]
})
print(f"🔫 Action + Anurag Kashyap: {model.predict(new_movie)[0]:.2f}/10")

