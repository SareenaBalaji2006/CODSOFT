import pandas as pd
df = pd.read_csv('advertising.csv')
print(df.head())
print(df.shape)
print(df.describe())
import matplotlib.pyplot as plt
df.plot(x='TV', y='Sales', kind='scatter')
plt.show()
from sklearn.model_selection import train_test_split
X = df[['TV', 'Radio', 'Newspaper']]
y = df['Sales']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print(X_train.shape)
from sklearn.linear_model import LinearRegression
model = LinearRegression()
model.fit(X_train, y_train)
print('Coefficients:', model.coef_)
print('Intercept:', model.intercept_)
from sklearn.metrics import mean_squared_error, r2_score
y_pred = model.predict(X_test)
print('MSE:', mean_squared_error(y_test, y_pred))
print('R2:', r2_score(y_test, y_pred))
new_ads = pd.DataFrame([[100, 25, 15]], columns=['TV', 'Radio', 'Newspaper'])
print('Predicted Sales:', model.predict(new_ads)[0])
import matplotlib.pyplot as plt

# Scatter plot of actual vs predicted sales
plt.scatter(y_test, y_pred, color='blue', alpha=0.6, label='Predicted vs Actual')

# Diagonal line showing perfect predictions
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()],
         color='red', linestyle='--', label='Perfect Prediction')

plt.xlabel('Actual Sales')
plt.ylabel('Predicted Sales')
plt.title('Actual vs Predicted Sales')
plt.legend()
plt.show()
print("Key Insights:")
print(f"TV impact per $: {model.coef_[0]:.3f}")
print(f"Radio impact per $: {model.coef_[1]:.3f}")
print(f"Newspaper impact per $: {model.coef_[2]:.3f}")
